import React from 'react';
import { useState } from 'react';

export default function Buttons() {
  // var count = 10;
  // 'useState' returns an array with 2 elements
  // 1. value of the state variable
  // 2. function is used to update the variable
  const [count, setCount] = useState(0);

  function handleIncrementCount() {
    console.log('Plus Button Clicked');
    console.log(count);
    // count++;
    // We no longer update the 'count' state variable directly.
    // We use React's setter (SetCount) to notify React that the state has changed.
    setCount(count + 1);

    console.log(count);
  }
  function handleIncrementCountReverse() {
    console.log('Button Minus');
    console.log(count);
    // count++;
    // We no longer update the 'count' state variable directly.
    // We use React's setter (SetCount) to notify React that the state has changed.
    setCount(count - 1);
    console.log(count);
    if (count > 0) {
      // Decrement one
      setCount(count - 1);
    } else {
      // Otherwise put a 0 there
      setCount(0);
    }
  }

  return (
    <div class="addminus">
      <button className="plus" onClick={handleIncrementCount}>
        +
      </button>
      <span class="counter"> {count} </span>
      <button className="minus" onClick={handleIncrementCountReverse}>
        -
      </button>
    </div>
  );
}
