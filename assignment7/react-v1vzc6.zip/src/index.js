import React from 'react';
import { createRoot } from 'react-dom/client';
import Item from './Item.js';
import Buttons from './Buttons.js';
import './index.css';

// var creates a variable that can be updated
// const creates a read-only variable.
const root = createRoot(document.querySelector('#root'));
root.render(
  <React.StrictMode>
    <div id="mainheader">
      <div className="scrollinghead">
        <p>
          WELCOME, NEW SHOPPERS! USE CODE 'ITP301' FOR 30.1% OFF ANY ALBUM,
          PHOTOBOOK, POSTER, OR PHOTOCARD! (NEW USERS ONLY){' '}
        </p>
      </div>
    </div>
    <br />
    <div id="main">
      <h1> add to your cart </h1>
      <hr id="header" />
      <br />
      <div className="item-gallery">
        <div className="itemblock">
          <Item
            src="https://upload.wikimedia.org/wikipedia/en/3/3e/Zerobaseone_-_Youth_in_the_Shade.jpg"
            alt="Youth In the Shade"
            color="blue"
            itemname="ZEROBASEONE - &ldquo;Youth in The Shade&rdquo; Debut EP"
            inclusions="CD, Poster, 2 Photocards, Freebie"
            price="25"
          />
          <Buttons />
        </div>
        <div className="itemblock">
          <Item
            src="https://upload.wikimedia.org/wikipedia/en/0/07/STAYC_-_STEREOTYPE.jpg"
            alt="STEREOTYPE"
            color="green"
            itemname="STAYC - &ldquo;STEREOTYPE&rdquo; Single Album"
            inclusions="CD, Poster, Photocard, Fragrance Card"
            price="29"
          />
          <Buttons />
        </div>
        <div className="itemblock">
          <Item
            src="https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/b1/77/f7/b177f74e-ff94-ac1f-0317-e0e120178661/093624869191.jpg/1200x1200bf-60.jpg"
            alt="Boy Alone"
            color="purple"
            itemname="Omah Lay - &ldquo;Boy Alone&rdquo; 1st Studio Album"
            inclusions="CD, Poster, Signed Postcard"
            price="39"
          />
          <Buttons />
        </div>
        <div className="itemblock">
          <Item
            src="https://f4.bcbits.com/img/a3675114225_65"
            alt="FOUNTAIN BABY"
            color="amaaraeblue"
            itemname="Amaarae - &ldquo;Fountain Baby&rdquo; 1st Studio Album"
            inclusions="CD, Poster, Signed Polaroid, Trucker Hat"
            price="45"
          />
          <Buttons />
        </div>
      </div>
      <br />
      <p className="priceview">
        {' '}
        Shopping Cart Total: $<span id="count2">0 </span>{' '}
      </p>
      <a href="https://uscwebdev.github.io/itp301-submissions-gracewithluv/">
        <button className="checkout">check out</button>
      </a>
    </div>
    <div id="footer">
      <p> © 2023 grace's album shop </p>
    </div>
  </React.StrictMode>
);
