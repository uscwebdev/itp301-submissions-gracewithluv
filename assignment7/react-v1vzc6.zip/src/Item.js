import React from 'react';

export default function Item(props) {
  return (
    <div className="item-right">
      <div className="thumbnail">
        <img
          className="portait"
          src={props.src}
          alt={props.alt + 'Album Cover'}
        />
      </div>
      <p>
        <span className={`zerobase ${props.color}`}>
          <b> {props.itemname} </b>{' '}
        </span>
      </p>
      <p>
        <b>Inclusions:</b> {props.inclusions}
      </p>
      <p>
        <span className={`zerobase ${props.color}`}>{'$' + props.price} </span>
      </p>
    </div>
  );
}
