import React from 'react';
import { useState } from 'react';

export default function Form() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [matchpw, setMatchpw] = useState('');
  const [phone, setPhone] = useState('');
  const [comment, setComment] = useState('');
  const [terms, setTerms] = useState(false);

  const [nameError, setNameError] = useState();
  const [passwordError, setPasswordError] = useState();
  const [matchpwError, setMatchpwError] = useState();
  const [submitError, setSubmitError] = useState();
  const [commentError, setCommentError] = useState();
  const [emailError, setEmailError] = useState();

  function handleNameChange(e) {
    console.log(e.target.value);
  }

  function handleSubmit(e) {
    // e.preventDefault();

    var foundError = false;

    if (name.length == 0) {
      // 이름이 없다
      foundError = true;
      setNameError('Name cannot be empty.');
    } else if (name.indexOf(' ') === -1) {
      foundError = true;
      console.log("Name doesn't have a space");
      setNameError('You must provide a full name.');
    } else {
      setNameError('');
    }

    if (password.length == 0) {
      foundError = true;
      setPasswordError('Password cannot be empty.');
    } else if (password.length < 5) {
      foundError = true;
      setPasswordError('Password must contain at least 5 characters.');
    } else if (password == password.toLowerCase()) {
      foundError = true;
      setPasswordError(
        'Password must contain uppercase and lowercase characters.'
      );
    } else if (password == password.toUpperCase()) {
      foundError = true;
      setPasswordError(
        'Password must contain uppercase and lowercase characters.'
      );
    } else {
      setPasswordError('');
    }
    if (matchpw != password) {
      foundError = true;
      setMatchpwError('Passwords do not match.');
    } else {
      setMatchpwError('');
    }
    if (email.length == 0 && phone.length == 0) {
      foundError = true;
      setEmailError('You must provide one.');
    } else {
      setEmailError('');
    }
    if (terms == false) {
      foundError = true;
      setSubmitError('You must accept Terms & Conditions.');
    } else {
      setSubmitError('');
    }
    if (comment.length >= 100) {
      foundError = true;
      setCommentError('Comments cannot exceed 100 characters.');
    } else {
      setCommentError('');
    }
    if (foundError == true) {
      // Have form validation errors.
      // Prevent it from submitting.
      e.preventDefault();
    } else {
      // No errors.
      // Display the confirmation.
      // Let the form submit.
      alert('The form was successfully submitted.');
    }
  }

  return (
    <div className="container my-3">
      <div className="row">
        <div className="col-12">
          <form onSubmit={handleSubmit}>
            <div className="my-3 row">
              <label htmlFor="full-name" className="col-sm-2 col-form-label">
                Full Name: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Tommy Trojan"
                  id="full-name"
                  // onChange={handleNameChange}
                  onChange={(e) => {
                    console.log(e.currentTarget.value);
                    setName(e.currentTarget.value);
                  }}
                  value={name}
                />
                <small id="name-error" className="form-text text-danger">
                  {nameError}
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="password" className="col-sm-2 col-form-label">
                Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  onChange={(e) => {
                    setPassword(e.currentTarget.value);
                    console.log(e.currentTarget.value);
                  }}
                  value={password}
                  className="form-control"
                  id="password"
                />
                <small id="name-error" className="form-text text-danger">
                  {passwordError}
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label
                htmlFor="password-confirm"
                className="col-sm-2 col-form-label"
              >
                Confirm Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  onChange={(e) => {
                    setMatchpw(e.currentTarget.value);
                    console.log(e.currentTarget.value);
                  }}
                  value={matchpw}
                  type="password"
                  className="form-control"
                  id="password-confirm"
                />
                <small id="name-error" className="form-text text-danger">
                  {matchpwError}
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label">
                Provide One: <span className="text-danger">*</span>
              </label>
              <div className="col-10">
                <div className="row">
                  <label htmlFor="email" className="col-sm-2 col-form-label">
                    Email:
                  </label>
                  <div className="col-sm-10">
                    <input
                      onChange={(e) => {
                        setEmail(e.currentTarget.value);
                        console.log(e.currentTarget.value);
                      }}
                      value={email}
                      type="text"
                      className="form-control"
                      placeholder="gnwankwo@usc.edu"
                      id="email"
                    />
                  </div>

                  <label
                    htmlFor="phone"
                    className="mt-sm-2 col-sm-2 col-form-label"
                  >
                    Phone:
                  </label>
                  <div className="mt-sm-2 col-sm-10">
                    <input
                      onChange={(e) => {
                        setPhone(e.currentTarget.value);
                        console.log(e.currentTarget.value);
                      }}
                      value={phone}
                      type="text"
                      className="form-control"
                      placeholder="(123) 456-7890"
                      id="phone"
                    />
                    <small id="name-error" className="form-text text-danger">
                      {emailError}
                    </small>
                  </div>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="comment" className="col-sm-2 col-form-label">
                Comments:
              </label>
              <div className="col-sm-10">
                <textarea
                  className="form-control"
                  id="comment"
                  onChange={(e) => {
                    setComment(e.currentTarget.value);
                    console.log(e.currentTarget.value);
                  }}
                  value={comment}
                ></textarea>
                <small id="comment-count" className="form-text text-right">
                  {comment.length} / 100
                </small>{' '}
                <br />
                <small id="name-error" className="form-text text-danger">
                  {commentError}
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label"></label>
              <div className="col-sm-10">
                <div className="form-check form-check-inline">
                  <input
                    onChange={() => {
                      setTerms(!terms);
                    }}
                    checked={terms}
                    className="form-check-input"
                    type="checkbox"
                    id="terms"
                  />
                  <label className="form-check-label" htmlFor="terms">
                    I accept Terms & Conditions.
                    <span className="text-danger">*</span>
                  </label>{' '}
                  <br />
                  <small id="name-error" className="form-text text-danger">
                    {submitError}
                  </small>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <div className="col-sm-10">
                <button type="submit" className="btn btn-primary">
                  Register
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
