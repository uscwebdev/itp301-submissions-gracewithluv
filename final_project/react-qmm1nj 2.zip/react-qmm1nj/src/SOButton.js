import React from 'react';

export default function SoldOut() {
  return (
    <div className="buttoni">
      <button
        id="soldout"
        onMouseEnter={() => {
          alert(
            'Item sold out. Select a new item or check website periodically for updates!'
          );
        }}
      >
        sold out
      </button>
    </div>
  );
}
