import React from 'react';
import { createRoot } from 'react-dom/client';
import Albumc from './Album.js';
import Vinyl from './Vinyl.js';
import SoldOut from './SOButton.js';
import Item from './Bestseller.js';
import Form from './Form.js';
import SongSearch from './SongSearch.js';
// import SongSearch from './Search.js';
import Reviews from './Reviews.js';

import './index.css';

const root = createRoot(document.querySelector('#root'));
root.render(
  <React.StrictMode>
    <div id="sidebar">
      <div className="myavatar">
        {' '}
        <img
          className="portrait"
          alt="grace nwankwo"
          src="https://github.com/uscwebdev/itp301-submissions-gracewithluv/blob/gh-pages/IMG_6006.png?raw=true"
        />{' '}
      </div>
      <p className="sidebarp"> ♡ grace's </p>
      <p> music marketplace </p>
      <p className="smallp"> all things music + merch </p>
      <p className="smallp"> #1 upcoming music site on vogue and nyt xx </p>
      <hr id="half" />
      <a href="#primary"> albums </a> <br />
      <a href="#vinyls"> vinyls + merch </a> <br />
      <a href="#bestsellas"> weekly bestsellers </a>
      <br />
      <a href="#reviewcont"> reviews </a> <br />
      <a href="#meetme"> meet the owner </a> <br />
      <a href="https://docs.google.com/document/d/1p6RpEnwVg_65ja0P1fNdleb21dT9xUxIlHvzOH7HmXI/edit?usp=sharing">
        {' '}
        project summary{' '}
      </a>{' '}
      <br />
      <a href="#michinform"> leave a comment </a> <br />
      {/* <a
        target="_blank"
        href="https://open.spotify.com/user/4y5hipawevb3afzn6preuvynn?si=2909a412f6454c77"
      >
        shop owner spotify
      </a> */}
    </div>

    <div id="primary" className="content">
      <p>
        — this week's <span className="special">featured</span> albums —
      </p>
      <Albumc />
    </div>
    <div id="vinyls" className="content">
      <p>
        — limited <span className="special">vinyls</span> +{' '}
        <span className="special">
          merchandise<span id="asterisk">*</span>
        </span>{' '}
        —{' '}
      </p>
      <Vinyl />
      <p className="notice">
        {' '}
        * These are limited items, so users can only buy <b> 2 </b> of these
        items to make it fair for other buyers.{' '}
      </p>
    </div>
    <div id="bestsellas" className="content">
      <p>
        — this week's <span className="special">bestsellers</span> —{' '}
      </p>
      <p>weekly bestsellers from the week of sunday, december 3rd:</p>
      <div className="albumpos" id="gold">
        <Item
          src="https://upload.wikimedia.org/wikipedia/en/7/71/Red_Velvet_-_Chill_Kill.png"
          alt="chillkill"
          rank={1}
          name="chill kill"
          artistname="red velvet"
          price={25}
          sales={320234}
        />
        <SoldOut />
      </div>

      <div className="albumpos" id="silver">
        <Item
          src="https://upload.wikimedia.org/wikipedia/en/thumb/5/5c/Eziokwu_mixtape.jpg/640px-Eziokwu_mixtape.jpg"
          alt="ODUMODUBLVCK ALBUM COVER"
          name="eziokwu"
          rank={2}
          artistname="odumodublvck"
          price={25}
          sales={230123}
        />
        <SoldOut />
      </div>
      <div className="albumpos" id="bronze">
        <Item
          src="https://gagasiworld.co.za/wp-content/uploads/2023/10/WhatsApp-Image-2023-10-11-at-15.38.54-1.jpeg"
          alt="KAMO MPHELA ALBUM COVER"
          name="dalie"
          rank={3}
          artistname="kamo mphela"
          price={12}
          sales={39234}
        />
        <SoldOut />
      </div>
    </div>
    <div id="reviewcont" className="content">
      <p>
        — read <span className="special">raving reviews</span> from shoppers —
      </p>
      <Reviews />
    </div>
    <div id="meetme" className="content">
      <h3> — project summary + meet me </h3>
      <div className="thumbnail">
        <img
          alt="profile picture"
          className="portrait"
          id="me"
          src="https://github.com/uscwebdev/itp301-submissions-gracewithluv/blob/gh-pages/IMG_2895.png?raw=true"
        />
      </div>

      <p>
        hello, everyone! my name is grace nwankwo, a health and human sciences
        third-year looking to sell some of my albums + merchandise, along with
        working with popular album producers
        <span className="special">
          &nbsp; (HYBE Labels, Atlantic Records, Mavins, etc.)
        </span>
        &nbsp; to make collecting albums & merchandise more cost-efficient to us
        college students + those who can't afford to spend a band on the music
        we love :) music needs to be shared and accessible to all!
      </p>
      <p id="follow">
        follow me on instagram&nbsp;
        <a
          className="dallalink"
          target="_blank"
          href="https://www.instagram.com/cnxgrace/"
        >
          here
        </a>
        &nbsp;for more store updates, including restock dates, new partners, and
        more! <br />
        <a className="dallalink" href="mailto:gnwankwo@usc.edu">
          email me
        </a>{' '}
        for all collabs and business messages 💌 xx
      </p>
    </div>
    <div className="content" id="search">
      <h3>
        {' '}
        — search an album on apple music with an apple id{' '}
        <a
          href="https://developer.apple.com/documentation/applemusicapi/"
          target="_blank"
        >
          buy!
        </a>
      </h3>

      <SongSearch />
      <span className="flop"> this didn't work....tears wasted</span>
    </div>
    <div className="content" id="michinform">
      <h3> — any concerns? want to join the mailing list for updates? </h3>
      <p> fill out the form below! </p>
      <Form />
    </div>
    <div id="footer">
      <p> the music marketplace</p>
    </div>
  </React.StrictMode>
);
