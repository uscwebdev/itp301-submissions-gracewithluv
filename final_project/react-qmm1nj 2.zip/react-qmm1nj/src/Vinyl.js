import React, { useState } from 'react';

const maxVinylCount = 2;
let currentVinylCount = 0;

export default function Vinyl() {
  const [vinylcount, setVinylCount] = useState(0);
  const [count, setCount] = useState(0);

  function handleNumberAdd(numba) {
    // console.log(testingCount);
    // testingCount++;
    setVinylCount(vinylcount + numba);
    // if (vinylcount >= 2) {
    //   setVinylCount(2);
    //   setCount(0);
    //   alert('Reduce Cart.');
    // }
  }

  function handleNumberSub(numba) {
    setVinylCount(vinylcount - numba);
    // if (vinylcount <= 0) {
    //   setVinylCount(0);
    // }
  }

  return (
    <div>
      <h4> cart ({vinylcount}) </h4>
      <div className="new-items">
        <div className="dallaalbumpos">
          <Item
            src="https://thesoundofvinyl.us/cdn/shop/products/LH_e9ee0344-6fce-44aa-97c7-5767b6b673f5_999x999.png?v=1677547124"
            alt="the miseducation of lauryn hill - lauryn hill vinyl"
            name="TMEOLH vinyl"
            artistname="lauryn hill"
            price={42}
            numba={1}
            parentEventHandler={() => handleNumberAdd(1)}
            parentEventHandler2={() => handleNumberSub(1)}
          />
          {/* <br /> <a> tracklist </a> */}
        </div>
        <div className="dallaalbumpos">
          <Item
            src="https://caldstore.com/cdn/shop/products/DSIN-CC029-BEIGE.png?v=1671395163&width=800"
            alt="ctrl"
            name="1987 hat"
            artistname="halcyon album inclusion"
            new="(never worn!)"
            price={19}
            numba={1}
            parentEventHandler={() => handleNumberAdd(1)}
            parentEventHandler2={() => handleNumberSub(1)}
          />
        </div>
        <div className="dallaalbumpos">
          <Item
            src="https://thesoundofvinyl.us/cdn/shop/products/szactrlgreen2lp_700x700.png?v=1680719828"
            alt="sza - ctrl"
            price={30}
            numba={1}
            name="ctrl (deluxe) vinyl"
            artistname="sza"
            parentEventHandler={() => handleNumberAdd(1)}
            parentEventHandler2={() => handleNumberSub(1)}
          />
        </div>
        <div className="dallaalbumpos">
          <Item
            src="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/469a92f1-392c-4d78-9a38-1f771ad11e07/df1prus-0b5c6327-98fb-4fa0-993e-7126d09112ae.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcLzQ2OWE5MmYxLTM5MmMtNGQ3OC05YTM4LTFmNzcxYWQxMWUwN1wvZGYxcHJ1cy0wYjVjNjMyNy05OGZiLTRmYTAtOTkzZS03MTI2ZDA5MTEyYWUucG5nIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.wdggnRvDzSCyQhqPqzSCqrEvDG4THpnyxlqjw171KE0"
            alt="lsfrm"
            price={85}
            numba={1}
            name="sanrio plushie"
            artistname="(signed by ateez's san)"
            parentEventHandler={() => handleNumberAdd(1)}
            parentEventHandler2={() => handleNumberSub(1)}
          />
        </div>
      </div>
    </div>
  );
}

function Item(props) {
  const [count, setCount] = useState(0);
  const [vinylcount, setVinylCount] = useState(0);

  function handleIncrementCount() {
    console.log(maxVinylCount);
    console.log(currentVinylCount);
    if (maxVinylCount > currentVinylCount) {
      setCount(count + 1);
      currentVinylCount++;
      props.parentEventHandler();
    } else {
      alert('You have exceeded a cart limit of two limited items. Try again.');
      setCount(count);
    }

    // console.log(count);
    // if (count == 2) {
    //   setCount(2);
    //   props.parentEventHandler();
    // } else {
    //   setCount(count + 1);
    // }
  }
  function handleIncrementCountReverse() {
    console.log('Minus Button Clicked');
    console.log(count);
    if (count > 0) {
      setCount(count - 1);
      currentVinylCount--;
      props.parentEventHandler2();
    }
  }
  return (
    <div className="addminus">
      <div className="item-details">
        <img src={props.src} alt={props.alt} />
        <p>
          {' '}
          {props.name} — ${props.price} <span className="new">{props.new}</span>
        </p>
        <p>{props.artistname}</p>
      </div>
      <button
        className="add"
        onClick={() => {
          handleIncrementCount();
          // handleIncrementCount(props.vinylcount);
          // props.parentEventHandler();
        }}
      >
        +
      </button>
      <span className="counter">&nbsp;&nbsp;{count}&nbsp;&nbsp;</span>
      <button
        className="subtract"
        onClick={() => {
          // handleIncrementCountReverse(props.vinylcount);
          handleIncrementCountReverse();
        }}
      >
        -
      </button>
    </div>
  );
}
