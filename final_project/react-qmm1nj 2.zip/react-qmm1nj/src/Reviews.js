import React, { useState } from 'react';

export default function Reviews() {
  const [src, setSrc] = useState(
    'https://images.loox.io/uploads/2022/6/5/VkUxMZ8uh_mid.jpg'
  );
  const [alt, setAlt] = useState(
    '"My album set came in perfect condition and came earlier than expected. 谢谢 Grace !" - Suyin Liu., hangzhou, china'
  );

  function handlePhotoChange(changedsrc, changedalt) {
    setSrc(changedsrc);
    setAlt(changedalt);
  }
  return (
    <div>
      <button
        className="rev"
        onClick={() => {
          handlePhotoChange(
            'https://images.loox.io/uploads/2022/6/5/VkUxMZ8uh_mid.jpg',
            '"My album set came in perfect condition and came earlier than expected. 谢谢 Grace !" - Suyin Liu., hangzhou, china'
          );
        }}
      >
        review no.1
      </button>
      <button
        className="rev"
        onClick={() => {
          handlePhotoChange(
            'https://i.pinimg.com/originals/3a/bf/4f/3abf4ff12f5688e847798ab42e229c44.jpg',
            '"shipping was quick, and grace even added freebies 🥹 will be buying again!" - halla, los angeles, usa'
          );
        }}
      >
        review no.2
      </button>
      <button
        className="rev"
        onClick={() => {
          handlePhotoChange(
            'https://fashionista.com/.image/ar_16:9%2Cc_fill%2Ccs_srgb%2Cq_auto:good%2Cw_1200/MjAwNTg0Mjg3MTY1MDk3MzM2/beyonce-renaissance-concert-fans-style-outfits-los-angeles-birthday.png',
            '"ordered my chrome miniskirt from here and ended up ON VOGUE?? FIVE MF STARS!!! ⭐️⭐️⭐️⭐️⭐️" - angel b., chicago, usa '
          );
        }}
      >
        review no.3
      </button>
      <button
        className="rev"
        onClick={() => {
          handlePhotoChange(
            'https://i.pinimg.com/564x/c5/16/94/c51694d7bdedeeb56d45ea404055eaee.jpg',
            '"pulled my biases! thank you grace for providing cheap albums for all engenes 🥰" - jake s., ho chi minh city, vietnam '
          );
        }}
      >
        review no.4
      </button>

      <button
        className="rev"
        onClick={() => {
          handlePhotoChange(
            'https://img.buzzfeed.com/buzzfeed-static/static/2023-10/10/13/campaign_images/6b87ae8b0c31/premiere-ayra-starr-takes-a-leap-of-faith-in-rhyt-3-1009-1696946281-3_16x9.jpg',
            'ordered earrings from here and now i have a grammy nomination...thank you grace. - ayra starr, lagos, nigeria '
          );
        }}
      >
        review no.5
      </button>
      <button
        className="rev"
        onClick={() => {
          handlePhotoChange(
            'https://victrola.com/cdn/shop/articles/Top_9_Rap_Vinyl_Records2.jpg?v=1623706087',
            '"got my girlfriend her first vinyl set and she LOVED it...we are now getting married. thank you grace!" - seth, santiago, chile '
          );
        }}
      >
        review no.6
      </button>
      <div id="gallery">
        {' '}
        <img className="landscape" src={src} alt={alt} />{' '}
        <p id="reviewp"> {alt} </p>{' '}
      </div>
    </div>
  );
}
