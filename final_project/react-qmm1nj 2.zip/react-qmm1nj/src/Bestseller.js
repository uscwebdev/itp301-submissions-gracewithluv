import React from 'react';

export default function Item(props) {
  return (
    <div className="new-items">
      <div className="albumpos">
        <img src={props.src} alt={props.alt} />
        <p>
          {' '}
          #{props.rank}: {props.name} — ${props.price}{' '}
          <span className="new">{props.new}</span>
        </p>
        <p>{props.artistname}</p>
        <p> weekly sales: {props.sales} </p>
      </div>
    </div>
  );
}
