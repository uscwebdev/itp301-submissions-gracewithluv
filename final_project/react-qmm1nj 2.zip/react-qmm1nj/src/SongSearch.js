import React, { useState } from 'react';
import $ from 'jquery';

export default function SongSearch() {
  const [searchTerm, setSearchTerm] = useState('');
  const [results, setResults] = useState([]);

  function handleOnSubmit(e) {
    e.preventDefault();
    $.ajax({
      url: 'https://api.music.apple.com/v1/catalog/us/albums/' + { searchTerm },
      dataType: 'json',
      success: function (data) {
        setResults(data.results);
      },
      error: function (error) {
        console.log(error);
      },
    });
  }

  return (
    <div>
      <form>
        <input
          type="text"
          placeholder="search for an album..."
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.currentTarget.value);
          }}
        />
        <button type="submit"> search </button>
      </form>
      {results.map((elt) => {
        return (
          <div className="results">
            <img src={elt.ArtworkUrl} />
            {elt.AlbumName}
            {elt.ArtistName}
          </div>
        );
      })}
    </div>
  );
}
