import React, { useState } from 'react';

export default function Form() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [selection, setSelection] = useState(-1);
  const [comment, setComment] = useState('');
  const [readterms, setReadTerms] = useState('');

  const [nameError, setNameError] = useState();
  const [emailError, setEmailError] = useState();
  const [selectionError, setSelectionError] = useState();
  const [termsError, setTermsError] = useState();
  const [commentError, setCommentError] = useState();

  function handleDaNameChange(e) {
    console.log(e.target.value);
  }

  function handleSubmit(e) {
    var foundError = false;
    if (name.length == 0) {
      foundError = true;
      setNameError('name cannot be empty. ');
    } else if (name.indexOf(' ') === -1) {
      foundError = true;
      setNameError('please provide a full name.');
    } else {
      setNameError('');
    }
    if (email.length == 0) {
      foundError = true;
      setEmailError('email cannot be empty.');
    } else if (email.indexOf('@') == -1) {
      foundError = true;
      setEmailError('please provide a full email.');
    } else if (email.indexOf('.') == -1) {
      foundError = true;
      setEmailError('please provide a full email.');
    } else {
      setEmailError('');
    }
    if (selection == -1) {
      foundError = true;
      setSelectionError('please select a reason.');
    } else {
      setSelectionError('');
    }
    if (comment.length == 0) {
      foundError = true;
      setCommentError('please submit a comment.');
    } else if (comment.length >= 500) {
      foundError = true;
      // style.color = red; idk why this isnt working hmm
      setCommentError('please reduce comment to below 500 characters.');
    } else {
      setCommentError('');
    }
    if (readterms == false) {
      foundError = true;
      setTermsError('you must read t&c to submit your form ;)');
    } else {
      setTermsError('');
    }
    if (foundError == true) {
      e.preventDefault();
    } else {
      alert(
        'thank you for your submission! our representatives will get back with you shortly ♡'
      );
    }
  }
  return (
    <div className="formi">
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="name">
            first + last name:<span id="asterisk">*</span>
          </label>
          <input
            type="text"
            placeholder="grace nwankwo"
            id="ireum"
            onChange={(e) => {
              setName(e.currentTarget.value);
            }}
            value={name}
          />
        </div>
        <div>
          <label htmlFor="email">
            email:<span id="asterisk">*</span>
          </label>
          <input
            type="text"
            placeholder="gnwankwo@usc.edu"
            onChange={(e) => {
              console.log(e.currentTarget.value);
              setEmail(e.currentTarget.value);
            }}
            value={email}
          />
        </div>
        <div>
          <label htmlFor="reason">
            {' '}
            what brings you here?<span id="asterisk">*</span>
          </label>
          <div>
            <select
              onChange={(e) => {
                setSelection(e.currentTarget.value);
              }}
              value={selection}
            >
              <option value="-1" disabled>
                {' '}
                please select a reason{' '}
              </option>
              <option value="mailinglist">join the mailing list </option>
              <option value="orders"> order inquiry/question </option>
              <option value="collab">partnerships/collabs</option>
              <option value="other">other comments</option>
            </select>
          </div>{' '}
          <div id="comment">
            <label htmlFor="comments">
              comment (character {comment.length} out of 500)
              <span id="asterisk">*</span>
            </label>
            <textarea
              placeholder="type n/a if you selected to join the mailing list!"
              id="rant"
              onChange={(e) => {
                setComment(e.currentTarget.value);
                console.log(e.currentTarget.value);
              }}
              value={comment}
            ></textarea>
            <br />
          </div>
          <div id="dalladiv">
            <label>
              have you read the t+c{' '}
              <a target="_blank" href="https://youtu.be/dQw4w9WgXcQ">
                here?
              </a>
            </label>
            <input
              onChange={() => {
                setReadTerms(true);
              }}
              checked={readterms}
              type="radio"
            />
            <label htmlFor="readtc" className="moved">
              yes
            </label>

            <input
              onChange={() => {
                setReadTerms(false);
              }}
              checked={readterms}
              type="radio"
              className="moved"
            />
            <label htmlFor="didntreadtc" className="moved">
              grace you're not funny
            </label>
          </div>
          <div id="buttonhome">
            <button type="submit" id="submit">
              submit
            </button>
          </div>
          <div className="erroneous">
            {' '}
            <span className="error">{nameError}</span>{' '}
            <span className="error">{emailError}</span>
            <span className="error">{selectionError}</span>
            <span className="error"> {commentError}</span>
            <span className="error">{termsError}</span>
          </div>
        </div>
      </form>
    </div>
  );
}
