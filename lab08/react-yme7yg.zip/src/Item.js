import React, { useState } from 'react';

export default function Subtotal() {
  const [subtotal, setSubtotal] = useState(0);

  function handlePriceAdd(price) {
    console.log('handlePriceAdd invoked');
    setSubtotal(subtotal + price);
  }

  function handlePriceSub(price) {
    console.log('handlePriceSub invoked');
    setSubtotal(subtotal - price);

    if (subtotal <= 0) {
      setSubtotal(0);
    }
  }

  return (
    <div className="item-gallery">
      <div className="itemblock">
        <Item
          src="https://upload.wikimedia.org/wikipedia/en/3/3e/Zerobaseone_-_Youth_in_the_Shade.jpg"
          alt="Youth In the Shade"
          color="#7db1de"
          itemname="ZEROBASEONE - Youth in The Shade Debut EP"
          inclusions="CD, Poster, 2 Photocards, Freebie"
          price={25}
          parentEventHandler={() => handlePriceAdd(25)}
          parentEventHandler2={() => handlePriceSub(25)}
        />
      </div>
      <div className="itemblock">
        <Item
          src="https://upload.wikimedia.org/wikipedia/en/0/07/STAYC_-_STEREOTYPE.jpg"
          alt="STEREOTYPE"
          color="#2a4630"
          itemname="STAYC - &ldquo;STEREOTYPE&rdquo; Single Album"
          inclusions="CD, Poster, Photocard, Fragrance Card"
          price={29}
          parentEventHandler={() => handlePriceAdd(29)}
          parentEventHandler2={() => handlePriceSub(29)}
        />
      </div>
      <div className="itemblock">
        <Item
          src="https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/b1/77/f7/b177f74e-ff94-ac1f-0317-e0e120178661/093624869191.jpg/1200x1200bf-60.jpg"
          alt="Boy Alone"
          color="#cda8f5"
          itemname="Omah Lay - &ldquo;Boy Alone&rdquo; 1st Studio Album"
          inclusions="CD, Poster, Signed Postcard"
          price={39}
          parentEventHandler={() => handlePriceAdd(39)}
          parentEventHandler2={() => handlePriceSub(39)}
        />
      </div>
      <div className="itemblock">
        <Item
          src="https://f4.bcbits.com/img/a3675114225_65"
          alt="FOUNTAIN BABY"
          color="#4b76c5"
          itemname="Amaarae - &ldquo;Fountain Baby&rdquo; 1st Studio Album"
          inclusions="CD, Poster, Signed Polaroid, Trucker Hat"
          price="45"
          parentEventHandler={() => handlePriceAdd(45)}
          parentEventHandler2={() => handlePriceSub(45)}
        />
      </div>
      <div>
        <p className="priceview">
          Shopping Cart Total: $<span id="count2">{subtotal}</span>
        </p>
      </div>
    </div>
  );
}

function Item(props) {
  const [count, setCount] = useState(0);

  function handleIncrementCount() {
    console.log('Plus Button Clicked');
    setCount(count + 1);
  }
  function handleIncrementCountReverse() {
    console.log('Minus Button Clicked');
    console.log(count);
    if (count > 0) {
      setCount(count - 1);
      props.parentEventHandler2();
    }
    console.log(count);
  }
  return (
    <div className="addminus">
      <div className="item-details">
        <img src={props.src} alt={props.alt} />
        <h2 style={{ color: props.color }}>{props.itemname}</h2>
        <p style={{ color: props.color }}>{props.inclusions}</p>
        <p style={{ color: props.color }}>Price: ${props.price}</p>
      </div>
      <button
        className="plus"
        onClick={() => {
          handleIncrementCount(props.subtotal);
          props.parentEventHandler();
        }}
      >
        +
      </button>
      <span className="counter">&nbsp;{count}&nbsp;</span>
      <button
        className="minus"
        onClick={() => {
          handleIncrementCountReverse(props.subtotal);
        }}
      >
        -
      </button>
    </div>
  );
}
