import React from 'react';
import { createRoot } from 'react-dom/client';
import Item from './Item.js';
import './index.css';
// var creates a variable that can be updated
// const creates a read-only variable.
const root = createRoot(document.querySelector('#root'));
root.render(
  <React.StrictMode>
    <div id="mainheader">
      <div className="scrollinghead">
        <p>WELCOME, NEW SHOPPERS! Store is closing because I'm over this. </p>
      </div>
    </div>
    <br />
    <div id="main">
      <h1> add to your cart </h1>
      <hr id="header" />
      <br />
      <div className="item-gallery">
        <div className="item-block">
          <Item />
        </div>
      </div>
      <br />
      {/* <p className="priceview">
        {' '}
        Shopping Cart Total: $<span id="count2">0 </span>{' '}
      </p> */}
      <a href="https://uscwebdev.github.io/itp301-submissions-gracewithluv/">
        <button className="checkout">check out</button>
      </a>
    </div>
    <div id="footer">
      <p> © 2023 grace's album shop </p>
    </div>
  </React.StrictMode>
);
