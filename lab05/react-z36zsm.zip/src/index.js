import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

// var creates a variable that can be updated
// const creates a read-only variable.
const root = createRoot(document.querySelector('#root'));
root.render(
  <React.StrictMode>
    <h1> grace chisomaga nwankwo 🇳🇬 </h1>
    <h3>
      email me <a href="mailto:gnwankwo@usc.edu">here</a>
    </h3>
    <hr />
    <br />
    <p>
      <b>favorite colors:</b> <span id="blue">baby blue</span> +{' '}
      <span id="black">black</span> + <span id="milk-tea">milk tea</span>
    </p>
    <p>
      <b>favorite website(s):</b>{' '}
      <a href="https://worldle.teuteuf.fr/">worldle</a> and{' '}
      <a href="https://flaggle.app/">flaggle</a> (as you can tell i love trivia)
    </p>
    <h3> fall 2023 classes </h3> <hr />
    <ul>
      <li className="example-class"> chem 322aL - organic chemistry </li>
      <li> psyc360 - abnormal psychology </li>
      <li> soci242 - sociolgy, human behavior, and health </li>
      <li> itp301 - front-end web development </li>
    </ul>
    <p>
      {' '}
      favorite activity: <hr />
      <img
        id="pic"
        src="https://i.pinimg.com/736x/12/61/e4/1261e4c63ac3302856b50396077eb7d0.jpg"
        alt="black girl traveling!"
      />{' '}
      <p> <b>traveling</b> </p>
    </p>
    <br />
    {/* <div className="thumbnail">
      <img
        src="https://yt3.googleusercontent.com/GdrOq1HZZw2eF1QDbB852k5K4uYLVtLBWgpCEC3v0-ZtBmbmxnAFY2-Jphjn-8CVM1meRo2p=s900-c-k-c0x00ffffff-no-rj"
        alt=""
      />
      <h4> Image Heading </h4>
      <p> caption for da image </p>
    </div>
    <div className="thumbnail">
      <img
        src="https://yt3.googleusercontent.com/GdrOq1HZZw2eF1QDbB852k5K4uYLVtLBWgpCEC3v0-ZtBmbmxnAFY2-Jphjn-8CVM1meRo2p=s900-c-k-c0x00ffffff-no-rj"
        alt=""
      />
      <h4> Image Heading </h4>
      <p> caption for da image </p>
    </div>
    <div className="thumbnail">
      <img
        src="https://yt3.googleusercontent.com/GdrOq1HZZw2eF1QDbB852k5K4uYLVtLBWgpCEC3v0-ZtBmbmxnAFY2-Jphjn-8CVM1meRo2p=s900-c-k-c0x00ffffff-no-rj"
        alt=""
      />
      <h4> Image Heading </h4>
      <p> caption for da image </p>
    </div>
    <div className="thumbnail">
      <img
        src="https://yt3.googleusercontent.com/GdrOq1HZZw2eF1QDbB852k5K4uYLVtLBWgpCEC3v0-ZtBmbmxnAFY2-Jphjn-8CVM1meRo2p=s900-c-k-c0x00ffffff-no-rj"
        alt=""
      />
      <h4> Image Heading </h4>
      <p> caption for da image </p>
    </div> */}
  </React.StrictMode>
);
