import React from 'react';

export default function UserProfile(props) {
  return (
    <div className="thumbnail">
      <img src={props.src} alt={props.alt + 'Profile Picture'} />
      <h4 className="username">
        {'@' + props.username} {'| rank ' + props.ranknumber} ({props.ranking})
        <span className="time"> &nbsp; {props.timestamp} </span>
      </h4>
      <p className="likes">
        <a href="https://uscwebdev.github.io/itp301-submissions-gracewithluv/">
          👍
        </a>{' '}
        {props.likecount} &nbsp; 👎 {props.dislikecount}
      </p>
      <p className="username">{props.comment}</p>
    </div>
  );
}
