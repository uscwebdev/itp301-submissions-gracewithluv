import React from 'react';
import { createRoot } from 'react-dom/client';
import UserProfile from './UserProfile.js';
import './index.css';

// var creates a variable that can be updated
// const creates a read-only variable.
const root = createRoot(document.querySelector('#root'));
root.render(
  <React.StrictMode>
    <div className="header">
      <h1 id="headerh1"> grace's music reviews </h1>
      <h3>bc i have the best music taste EVA</h3>
    </div>
    <div className="maincontent">
      <div className="timestamp">
        <div id="diff">
          <h2> grace's song of the week (08/20/2023) </h2>{' '}
        </div>
        <div id="right">
          <p id="caption">
            posted 2023/08/21 <br /> @graciellie
          </p>
          <img
            id="pfp"
            src="https://raw.githubusercontent.com/uscwebdev/itp301-submissions-gracewithluv/b45e2b73b8cebd983c93fb845b702f75031055ec/IMG_2636.jpg"
          />{' '}
        </div>
      </div>
      <br />
      <img
        id="mainthumb"
        src="https://i.ytimg.com/vi/E7KE1kAoCEY/maxresdefault.jpg"
      />
      <div className="opening">
        <p>
          <span id="award">'song of the week' award goes to:</span>{' '}
          <b>ZEROBASEONE - IN BLOOM! </b>{' '}
        </p>
        <p>
          {' '}
          listen to the full song + watch the whole video{' '}
          <a
            target="_blank"
            href="https://www.youtube.com/watch?v=trzeUClQIIg&pp=ygUIaW4gYmxvb20%3D"
          >
            here
          </a>
        </p>
      </div>
      <p>
        yall...if having one of the best debut songs in a WHILE was a crime, zb1
        (abbreviation for ZEROBASEONE) would be BEHIND BARS! LOCKED UP! and yes
        all nine of them, even the '07 liner idc LMAOOO. yall need to stop
        playing with zb1!!! this song reminds me of blue raspberry and yellow
        flowers and sunshine and relaxing on a bed after a long day...this is a
        v weird way to describe a song but every time i hear this song i'm
        literally so happy omg. think of every good emotion you've had mixed
        with a tinge of sadness/nostalgia and it's this song
      </p>
      <p>
        no offense but i didn't watch the survival show they were on (BOYS
        PLANET 999) because i don't care that much for boy group survival shows
        BUT i should have watched it...they're literally soooo talented and
        funny. kcon rlly introduced me to them and i got an interaction w
        hanbin??? he literally saw my sign and waved im gonna cry again...i'm
        proud to say i am a zerose!!!!! waiting for the comeback in november!!!
      </p>
      <p className="bias">
        bias: jiwoong (my bf LMAOOOOimsoseriousOOOO) and possibly zhanghao!!! |
        bias wrecker(s): taerae + hanbin
      </p>{' '}
      <br />
      <h1> COMMENTS(14) </h1>
      <hr id="commentline" />
      <UserProfile
        src="https://i.pinimg.com/564x/b9/eb/2d/b9eb2d0bfa6d717f94f28775da0ee2ab.jpg"
        alt="yunjin"
        username="lesserafleurs"
        ranknumber="3"
        ranking="trainee"
        timestamp="08/21/2023 at 9:39am"
        likecount="139"
        dislikecount="0"
        comment="it's always &ldquo;wyd&ldquo; and never &ldquo;I'LL KEEP RUNNING TOWARDS YOU BECAUSE I BELIEVE
          IN MY FAITH CALLED YOU. EVEN IF EVERYTHING AROUND US CHANGES, THE
          HIGHLIGHT OF MY LIFE AND MY REASON TO KEEP GOING IS YOU&ldquo; AAAAA I LOVE
          THEM"
      />
      <UserProfile
        src="https://i.pinimg.com/564x/1a/89/ee/1a89eec8a3d38a930a9474f3ffdc83ff.jpg"
        alt="jake and sunghoon"
        username="enhyfemz"
        ranknumber="1"
        ranking="novice"
        timestamp="08/21/2023 at 10:23pm"
        likecount="5"
        dislikecount="202"
        comment="enhypen's given-taken solo'd and outperformed stay mad!"
      />
      <UserProfile
        src="https://i.pinimg.com/564x/e5/31/c5/e531c57da1ba044a13e21bfaabd56270.jpg"
        alt="summerwalker"
        username="summerwalker ✅"
        ranknumber="CELEB"
        ranking="DEBUTED SOLO"
        timestamp="08/22/2023 at 12:09am"
        likecount="1934"
        dislikecount="25"
        comment="love these boys 🤍 collab coming soon, just y'all waittt!!
        #SummerxZeroBaseOne"
      />
      <UserProfile
        src="https://i.pinimg.com/564x/ab/86/13/ab86137a036df2cfcc30f1fe1a548f7f.jpg"
        alt="krystaline"
        username="krystaaaaaal"
        ranknumber="18"
        ranking="debut lineup pick"
        timestamp="08/22/2023 at 2:22am"
        likecount="32"
        dislikecount="7"
        comment="when we are having our joint wedding? you marry jiwoong i marry taerae???? 😮‍💨"
      />
      <UserProfile
        src="https://i.pinimg.com/564x/a9/40/55/a94055743c71c2cad3f471d87abde709.jpg"
        alt="san"
        username="choisan ✅"
        ranknumber="CELEB"
        ranking="DEBUTED IN ATEEZ"
        timestamp="08/23/2023 at 6:25pm"
        likecount="3256"
        dislikecount="12"
        comment="are you actually leaving me for a new man..."
      />
      <UserProfile
        src="https://i.pinimg.com/564x/8a/34/de/8a34de7d7f9e54776e8db955ab83f83a.jpg"
        alt="megan thee stallion"
        username="megantheestallion ✅"
        ranknumber="CELEB"
        ranking="DEBUTED SOLO"
        timestamp="08/23/2023 at 8:31pm"
        likecount="2088"
        dislikecount="28"
        comment="grace and jiwoong THEE HOTTIES!!!!!"
      />
      <button id="load-btn" className="btn btn-primary">
        <a href="https://uscwebdev.github.io/itp301-submissions-gracewithluv/">
          Load More
        </a>
      </button>
    </div>
    <div className="charts">
      <p>
        <b> GRACE CHART TOP 10 (Week of 08/20/2023)</b>
        <br />
        <br />
        <hr />{' '}
      </p>
      <div className="thumbnail2">
        <img
          src="https://m.media-amazon.com/images/I/71-Ky43N7RL._UF1000,1000_QL80_.jpg"
          alt="SATURNO album cover"
        />
        <h4 id="top">NUMBER 1: PUNTO 40 (-) </h4>
        <p> RAUW ALEJANDRO </p>
        <p>
          {' '}
          Album: <i> Saturno </i>
        </p>
      </div>
      <div className="thumbnail2">
        <img
          src="https://i.scdn.co/image/ab67616d0000b27354b6c54e83c4154c974c1059"
          alt="OMAH LAY ALBUM COVER"
        />
        <h4 id="top2">NUMBER 2: JOANNA (+12)</h4>
        <p> OMAH LAY </p>
        <p>
          {' '}
          Album: <i> Boy Alone (Deluxe) </i>
        </p>
      </div>
      <div className="thumbnail2">
        <img
          src="https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/e9/3e/3e/e93e3e48-6f68-c368-83b4-d15d54fe53c2/075679673787.jpg/1200x1200bf-60.jpg"
          alt="I TOLD THEM ALBUM COVER"
        />
        <h4 id="top3">NUMBER 3: GIZA (feat. Seyi Vibes) (+24) </h4>
        <p> BURNA BOY </p>
        <p>
          {' '}
          Album: <i> I Told Them... </i>
        </p>
      </div>{' '}
      <div className="thumbnail2">
        <img
          src="https://e.snmc.io/i/1200/s/c6498953a5cdbbfc5c78c9163027ce64/10956060"
          alt="mnike album cover"
        />
        <h4 className="top1">#4 - MNIKE (+10) </h4>
        <p> TYLER ICU </p>
        <p>
          {' '}
          Album: <i> MNIKE - SINGLE </i>
        </p>
      </div>{' '}
      <div className="thumbnail2">
        <img
          src="https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/1c/42/2e/1c422e9c-27a2-de9d-ecac-4fc7e7822cd5/193017042863.jpg/600x600bf-60.jpg"
          alt="gone gold album cover"
        />
        <h4 className="top1">#5 - 有吗炒面 ALGTR (+1) </h4>
        <p> LEXIE LIU </p>
        <p>
          {' '}
          Album: <i> 上线了 GONE GOLD </i>
        </p>
      </div>
      <div className="thumbnail2">
        <img
          src="https://i.etsystatic.com/36607478/r/il/24073a/4719329881/il_fullxfull.4719329881_38v3.jpg"
          alt="MANANA SERA BONITO"
        />
        <h4 className="top1">#6 - KARMIKA (+10)</h4>
        <p> KAROL G FEAT. BAD GYAL + SEAN PAUL </p>
        <p>
          {' '}
          Album: <i> MAÑ/SRA/BONITO </i>
        </p>
      </div>
      <div className="thumbnail2">
        <img
          src="https://i.scdn.co/image/ab67616d0000b27354b6c54e83c4154c974c1059"
          alt="BOY ALONE"
        />
        <h4 className="top1">#7 - SOSO (-6)</h4>
        <p> OMAH LAY</p>
        <p>
          {' '}
          Album: <i> BOY ALONE </i>
        </p>
      </div>
      <div className="thumbnail2">
        <img
          src="https://cdns-images.dzcdn.net/images/cover/657d2e7cc3acb311cf5bf659c42fd4c7/500x500.jpg"
          alt="jayo ALBUM COVER"
        />
        <h4 className="top1">#8 - 22 (+17)</h4>
        <p> JAYO </p>
        <p>
          {' '}
          Album: <i> 22 - Single </i>
        </p>
      </div>{' '}
      <div className="thumbnail2">
        <img
          src="https://upload.wikimedia.org/wikipedia/en/f/fd/Jimin_Face_debut_album_cover.png"
          alt="face album cover"
        />
        <h4 className="top1">#9 - LIKE CRAZY (+2)</h4>
        <p> JIMIN OF BTS </p>
        <p>
          {' '}
          Album: <i> FACE </i>
        </p>
      </div>
      <div className="thumbnail2">
        <img
          src="https://upload.wikimedia.org/wikipedia/en/0/02/Fromis_9_-_Unlock_My_World.png"
          alt="ULMW"
        />
        <h4 className="top1">#10 - ATTITUDE (-10)</h4>
        <p> fromis_9 </p>
        <p>
          {' '}
          Album: <i> UNLOCK MY WORLD </i>
        </p>
      </div>
      <b> — SONGS BUBBLING UNDER TOP 10) — </b>
      <div className="thumbnail2">
        <img
          src="https://preview.redd.it/230712-odd-eye-circle-version-up-digital-album-cover-v0-q3ym7g9y1ibb1.jpg?auto=webp&s=b3927b8186443ee44d50845aedc665b54d78a41b"
          alt="OEC ALBUM COVER"
        />
        <h4 className="top1">#11 - JE NE SAIS QUOI (NEW)</h4>
        <p> ODD EYE CIRCLE </p>
        <p>
          {' '}
          Album: <i> OEC VERSION UP </i>
        </p>
      </div>
      <div className="thumbnail2">
        <img
          src="https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/e9/3e/3e/e93e3e48-6f68-c368-83b4-d15d54fe53c2/075679673787.jpg/1200x1200bf-60.jpg"
          alt="I TOLD THEM ALBUM COVER"
        />
        <h4 className="top1">#12 - CITY BOYS (+34) </h4>
        <p> BURNA BOY </p>
        <p>
          {' '}
          Album: <i> I TOLD THEM... </i>
        </p>
      </div>
    </div>
  </React.StrictMode>
);
