import React from 'react';
import { useState } from 'react';

export default function Buttons(props) {
  function handleClick() {
    document.querySelector('#display').src = props.image;
    document.querySelector('#display').alt = props.alt;
    document.querySelector('#caption').innerHTML = props.alt;
    console.log('clicked!');
  }
  return (
    <button onClick={handleClick} className="checkout">
      {props.name}
    </button>
  );
}
