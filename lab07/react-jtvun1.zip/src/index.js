import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import Image01 from './Image01.js';
import Buttons from './Buttons.js';

// var creates a variable that can be updated
// const creates a read-only variable.
const root = createRoot(document.querySelector('#root'));
root.render(
  <React.StrictMode>
    <div id="main">
      <h1> grace's photo gallery of interests (iii) </h1>
      <hr id="header" />
      <p> explore some of my interests by clicking on the photos below :) </p>
      <br />
      <Buttons
        name="image no.1"
        image="https://i.pinimg.com/564x/87/e0/6e/87e06ec39e0c62f3be92fa11b22afe9d.jpg"
        alt="language learning (korean + spanish)"
      />
      <Buttons
        name="image no.2"
        image="https://i.pinimg.com/564x/02/c2/15/02c215338c78f9a1e106a652153d05e6.jpg"
        alt="going to concerts (ateez, bts, rema)"
      />
      <Buttons
        name="image no.3"
        image="https://i.pinimg.com/564x/59/12/e4/5912e4731ab036fea12825e81c2216f5.jpg"
        alt="baking + cooking"
      />
      <Buttons
        name="image no.4"
        image="https://i.pinimg.com/564x/6f/b8/b7/6fb8b7daf986229c7390bf77365fdc4e.jpg"
        alt="cafehopping"
      />
      <Buttons
        name="image no.5"
        image="https://i.pinimg.com/564x/68/76/9d/68769d30fcc238b91b5c33d563a6a9fc.jpg"
        alt="hanging out w/ friends"
      />

      <br />
      <br />
      <div className="thumbnail2">
        /*{' '}
        <img
          className="portait"
          id="display"
          src="https://i.pinimg.com/564x/87/e0/6e/87e06ec39e0c62f3be92fa11b22afe9d.jpg"
          alt="Chinese language learning"
        />
      </div>

      <p id="caption"> language learning (korean + spanish) </p>
      <a href="https://uscwebdev.github.io/itp301-submissions-gracewithluv/">
        <button class="return">back home</button>
      </a>
    </div>
  </React.StrictMode>
);
