import React, { useState } from 'react';

export default function Albumc() {
  const [albumc, setAlbumc] = useState(0);

  function handleNumberAdd(numba) {
    setAlbumc(albumc + numba);
  }

  function handleNumberSub(numba) {
    setAlbumc(albumc - numba);
    if (albumc <= 0) {
      setAlbumc(0);
    }
  }

  return (
    <div>
      <h4> cart ({albumc}) </h4>
      <div className="new-items">
        <div className="albumpos">
          <Item
            src="https://i.ebayimg.com/images/g/xYcAAOSwFb9j2pMF/s-l500.jpg"
            alt="SATURNO"
            name="saturno"
            artistname="rauw alejandro"
            price={30}
            numba={1}
            parentEventHandler={() => handleNumberAdd(1)}
            parentEventHandler2={() => handleNumberSub(1)}
          />
          {/* <br /> <a> tracklist </a> */}
        </div>
        <div className="albumpos">
          <Item
            src="https://i.scdn.co/image/ab67616d0000b273175ca9fe498f5c7a4ed46e79"
            alt="mavins"
            name="chapter x"
            artistname="mavins"
            new="(new!)"
            price={19}
            numba={1}
            parentEventHandler={() => handleNumberAdd(1)}
            parentEventHandler2={() => handleNumberSub(1)}
          />
        </div>
        <div className="albumpos">
          <Item
            src="https://upload.wikimedia.org/wikipedia/en/d/d3/Madison_Beer_Silence_Between_Songs.png"
            alt="Boy Alone"
            color="#cda8f5"
            price={15}
            numba={1}
            name="silence between songs"
            artistname="madison beer"
            parentEventHandler={() => handleNumberAdd(1)}
            parentEventHandler2={() => handleNumberSub(1)}
          />
        </div>
        <div className="albumpos">
          <Item
            src="https://wp.dailybruin.com/images/2023/05/web.ae_.unforgiven.review.courtesy-1024x1024.jpg"
            alt="lsfrm"
            price={29}
            numba={1}
            name="unforgiven"
            artistname="lesserafim"
            parentEventHandler={() => handleNumberAdd(1)}
            parentEventHandler2={() => handleNumberSub(1)}
          />
        </div>
        {/* <div className="priceview">
          {/* <p>
            Shopping Cart Total: $<span id="count2">{subtotal}</span>
          </p> */}
        {/* <img id="cart" src="" />{subtotal} */}
      </div>
    </div>
  );
}

function Item(props) {
  const [count, setCount] = useState(0);

  function handleIncrementCount() {
    console.log('Plus Button Clicked');
    setCount(count + 1);
    props.parentEventHandler();
  }
  function handleIncrementCountReverse() {
    console.log('Minus Button Clicked');
    console.log(count);
    if (count > 0) {
      setCount(count - 1);
      props.parentEventHandler2();
    }
  }
  return (
    <div className="addminus">
      <div className="item-details">
        <img src={props.src} alt={props.alt} />
        <p>
          {' '}
          {props.name} — ${props.price} <span class="new">{props.new}</span>
        </p>
        <p>{props.artistname}</p>
      </div>
      <button
        className="add"
        onClick={() => {
          handleIncrementCount(props.albumc);
          props.parentEventHandler();
        }}
      >
        +
      </button>
      <span className="counter">&nbsp;&nbsp;{count}&nbsp;&nbsp;</span>
      <button
        className="subtract"
        onClick={() => {
          handleIncrementCountReverse(props.albumc);
        }}
      >
        -
      </button>
    </div>
  );
}
