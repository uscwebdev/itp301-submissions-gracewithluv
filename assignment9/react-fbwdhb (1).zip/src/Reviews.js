import React, { useState } from 'react';
import { useState } from 'react';

export default function Photo() {
  const [src, setSrc] = useState(
    'https://i.pinimg.com/564x/4b/3d/f2/4b3df29147c60cb020846bd409542dfb.jpg'
  );
  const [alt, setAlt] = useState(
    'Love my album set. Thank you Grace! - Kathy L., China'
  );

  function handlePhotoChange(changedsrc, changedalt) {
    setSrc(changedsrc);
    setAlt(changedalt);
  }
  return (
    <div className="content">
      <div className="gallery">
        <button
          onClick={() => {
            handlePhotoChange(
              'https://i.pinimg.com/564x/c0/2e/d0/c02ed0d641581a4def2f5c23a74ec207.jpg',
              'peace within shirt ate down. shipping was fast and grace even added freebies. best seller ever'
            );
          }}
        >
          album review no.1
        </button>
        <button
          onClick={() => {
            {
              handlePhotoChange;
            }
          }}
        >
          album review no.2
        </button>
        <div>
          <img src={src} alt={alt} />
        </div>
        <p> {alt} </p>
      </div>
    </div>
  );
}
