import React from 'react';
import { createRoot } from 'react-dom/client';
import Albumc from './Album.js';
import Vinyl from './Vinyl.js';
import Photo from './Reviews.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));
root.render(
  <React.StrictMode>
    <div id="sidebar">
      <div className="myavatar">
        {' '}
        <img
          alt="grace nwankwo"
          id="myavatar"
          src="https://github.com/uscwebdev/itp301-submissions-gracewithluv/blob/gh-pages/IMG_1964.png?raw=true"
        />{' '}
      </div>
      <p className="sidebarp"> ♡ grace's </p>
      <p> music marketplace </p>
      <p className="smallp"> all things music </p>
      <p className="smallp"> #1 upcoming music site on vogue and nyt xx </p>
      <hr id="half" />
      <a href="#primary"> albums </a> <br />
      <a href="#vinyls"> vinyls + merch </a> <br />
      <a href="#bestsella"> weekly bestsellers </a>
      <br />
      <a href="#reviewcont"> reviews </a> <br />
      <a href="#meetme"> meet the owner </a> <br />
      <a
        target="_blank"
        href="https://open.spotify.com/user/4y5hipawevb3afzn6preuvynn?si=2909a412f6454c77"
      >
        shop owner spotify
      </a>
    </div>

    <div id="primary" className="content">
      <p>
        — this week's <span className="special">featured</span> albums —
      </p>
      <Albumc />
    </div>
    <div id="vinyls" className="content">
      <p>
        — classic <span className="special">vinyls</span> + rare{' '}
        <span className="special">merchandise</span> —{' '}
      </p>
      <Vinyl />
    </div>
    <div id="bestsella" className="content">
      <p>
        — this week's <span className="special">bestsellers!</span> —{' '}
      </p>
      <p>
        weekly bestsellers list generate after a week of collecting shopper
        data, posted every tuesday!
      </p>
      <img alt="loading bar" id="giffygif" src="https://i.gifer.com/ZWdx.gif" />
    </div>
    <div id="reviewcont" className="content">
      <p>
        — read <span className="special">raving reviews</span> from shoppers
      </p>
      <Photo />
    </div>
    <div id="meetme" className="content">
      <h3> — project summary + intro </h3>
      <div className="thumbnail">
        <img
          alt="profile picture"
          className="portait"
          id="me"
          src="https://github.com/uscwebdev/itp301-submissions-gracewithluv/blob/gh-pages/IMG_2895.png?raw=true"
        />
      </div>
      <p>
        hello, everyone! my name is grace nwankwo, a health and human sciences
        third-year looking to sell some of my albums + merchandise, along with
        working with popular album producers
        <span className="special">
          (HYBE Labels, Atlantic Records, Mavins, etc.)
        </span>
        to make collecting albums, merchandise, and more cost-efficient to us
        college students + those who can't afford to spend a band on the music
        we love :) music needs to be shared and accessible to all!
      </p>
      <p id="follow">
        follow me on instagram
        <a
          className="dallalink"
          target="_blank"
          href="https://www.instagram.com/cnxgrace/"
        >
          here{' '}
        </a>
        for more store updates, including restock dates, new partners, and more!
        <a className="dallalink" href="mailto:gnwankwo@usc.edu">
          email me
        </a>
        for all collabs and business messages 💌 xx
      </p>
    </div>
    <div id="footer">
      <p> the music marketplace</p>
    </div>
  </React.StrictMode>
);
